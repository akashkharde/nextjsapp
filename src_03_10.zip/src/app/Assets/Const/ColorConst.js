// colorConst.js
export const primary = '#6919FF';
export const neutralsNine = '#060918';
export const neutralsEight = '#161A2C';
export const neutralsSeven = '#23263B';
export const neutralsSix = '#2E364F';
export const neutralsFive = '#4D5775';
export const neutralsFour = '#6F7A9B';
export const neutralsThree = '#96A1C0';
export const neutralsTwo = '#C7D0E5';
export const neutralsOne = '#F0F2FE';
export const neutralsZ = 'red';
export const success = '#00F090';
export const warning = '#FFDC30';
export const error = '#FF2E5B';
export const red = 'red';

